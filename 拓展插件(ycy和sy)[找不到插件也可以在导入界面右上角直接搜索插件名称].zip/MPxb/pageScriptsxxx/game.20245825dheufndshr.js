if (/https:\/\/www\.66rpg\.com/.test(location.href) || /https:\/\/m\.66rpg\.com\/h5\/\d+/.test(location.href)) {
    if (/https:\/\/www\.66rpg\.com\/game\/\d+/.test(location.href)) {
        if (document.getElementById("gameMainBox")) {
            const gameIf = document.getElementById("gameMainBox").contentWindow
            // 保存原始的方法
            const originalGetOwnPropertyNames = gameIf.Object.getOwnPropertyNames;
            const originalForEach = gameIf.Array.prototype.forEach;
            // 重写 Object.getOwnPropertyNames 方法
            gameIf.Object.getOwnPropertyNames = function (obj) {
                // 如果对象是 window，则返回空数组
                if (obj === document.getElementById("gameMainBox").contentWindow) {
                    document.getElementById("gameMainBox").contentWindow.Object.getOwnPropertyNames = originalGetOwnPropertyNames
                    document.getElementById("gameMainBox").contentWindow.Array.prototype.forEach = originalForEach
                    return []
                }
                // 否则调用原始的方法
                return originalGetOwnPropertyNames(obj);
            };
            // 重写 forEach 方法
            gameIf.Array.prototype.forEach = function (callback, thisArg) {
                const globalV = Object.getOwnPropertyNames(document.getElementById("gameMainBox").contentWindow)
                // 遍历数组
                originalForEach.call(this, function (element, index, array) {
                    // 检查元素是否是字符串
                    if (globalV.length === array.length && typeof element === 'string') {
                        // 如果元素是字符串，进行特定处理
                        if (!globalV.includes(element)) {
                            // 调用原始回调函数
                            callback.call(thisArg, element, index, array);
                        } else {
                            if (index === array.length - 1) {
                                document.getElementById("gameMainBox").contentWindow.Object.getOwnPropertyNames = originalGetOwnPropertyNames
                                document.getElementById("gameMainBox").contentWindow.Array.prototype.forEach = originalForEach
                            }
                        }
                    } else {
                        // 对于非字符串元素，直接调用原始回调函数
                        callback.call(thisArg, element, index, array);
                    }
                }, thisArg);
            };
        } else {
            // 创建 MutationObserver 实例并传入回调函数
            const observer = new MutationObserver((mutationsList) => {
                for (const mutation of mutationsList) {
                    // 处理子节点的变化
                    if (mutation.type === 'childList') {
                        const gameMainBox = document.getElementById("gameMainBox");

                        if (gameMainBox) {
                            const gameIf = gameMainBox.contentWindow;
                            // 保存原始的方法
                            const originalGetOwnPropertyNames = gameIf.Object.getOwnPropertyNames;
                            const originalForEach = gameIf.Array.prototype.forEach;
                            // 重写 Object.getOwnPropertyNames 方法
                            gameIf.Object.getOwnPropertyNames = function (obj) {
                                // 如果对象是 window，则返回空数组
                                if (obj === document.getElementById("gameMainBox").contentWindow) {
                                    document.getElementById("gameMainBox").contentWindow.Object.getOwnPropertyNames = originalGetOwnPropertyNames
                                    document.getElementById("gameMainBox").contentWindow.Array.prototype.forEach = originalForEach
                                    return []
                                }
                                // 否则调用原始的方法
                                return originalGetOwnPropertyNames(obj);
                            };
                            // 重写 forEach 方法
                            gameIf.Array.prototype.forEach = function (callback, thisArg) {
                                const globalV = Object.getOwnPropertyNames(document.getElementById("gameMainBox").contentWindow)
                                // 遍历数组
                                originalForEach.call(this, function (element, index, array) {
                                    // 检查元素是否是字符串
                                    if (globalV.length === array.length && typeof element === 'string') {
                                        // 如果元素是字符串，进行特定处理
                                        if (!globalV.includes(element)) {
                                            // 调用原始回调函数
                                            callback.call(thisArg, element, index, array);
                                        } else {
                                            if (index === array.length - 1) {
                                                document.getElementById("gameMainBox").contentWindow.Object.getOwnPropertyNames = originalGetOwnPropertyNames
                                                document.getElementById("gameMainBox").contentWindow.Array.prototype.forEach = originalForEach
                                            }
                                        }
                                    } else {
                                        // 对于非字符串元素，直接调用原始回调函数
                                        callback.call(thisArg, element, index, array);
                                    }
                                }, thisArg);
                            };
                            // 停止观察，因为我们只需要做一次设置
                            observer.disconnect();
                        }
                    }
                }
            });
            // 配置观察选项
            const config = {
                childList: true,   // 观察子节点的变化
                subtree: true      // 观察整个文档
            };
            // 开始观察整个 document
            if (document.body) {
                observer.observe(document.body, config);
            } else {
                observer.observe(document, config);
            }
        }
    } else if (/https:\/\/m\.66rpg\.com\/h5\/\d+/.test(location.href)) {
        const originalGetOwnPropertyNames = Object.getOwnPropertyNames;
        const originalForEach = Array.prototype.forEach;
        // 重写 Object.getOwnPropertyNames 方法
        Object.getOwnPropertyNames = function (obj) {
            // 如果对象是 window，则返回空数组
            if (obj === window) {
                Object.getOwnPropertyNames = originalGetOwnPropertyNames
                Array.prototype.forEach = originalForEach
                return []
            }
            // 否则调用原始的方法
            return originalGetOwnPropertyNames(obj);
        };
        Array.prototype.forEach = function (callback, thisArg) {
            const globalV = originalGetOwnPropertyNames(window)
            // 遍历数组
            originalForEach.call(this, function (element, index, array) {
                if (globalV.length === array.length && typeof element === 'string') {
                    // 如果元素是字符串，进行特定处理
                    if (!globalV.includes(element)) {
                        // 调用原始回调函数
                        callback.call(thisArg, element, index, array);
                    } else {
                        if (index === array.length - 1) {
                            Object.getOwnPropertyNames = originalGetOwnPropertyNames
                            Array.prototype.forEach = originalForEach
                        }
                    }
                } else {
                    // 对于非字符串元素，直接调用原始回调函数
                    callback.call(thisArg, element, index, array);
                }
            }, thisArg);
        };

    }
}
// // 创建一个代理来拦截 Error 对象的 stack 属性
// if (document.getElementById("gameMainBox")) {
//     const originalError = document.getElementById("gameMainBox").contentWindow.Error;

//     document.getElementById("gameMainBox").contentWindow.Error = new Proxy(originalError, {
//         construct(target, args) {
//             const error = new target(...args);
//             return new Proxy(error, {
//                 get(obj, prop) {
//                     if (prop === 'stack') {
//                         return obj.stack
//                             .replace(/\/userscript\.html/g, '/muamua/qq.html')
//                             .replace(/\.user\.js/g, '/muamua.qq.js');
//                     }
//                     return Reflect.get(obj, prop);
//                 }
//             });
//         }
//     });
// }
// const originalError = Error;

// Error = new Proxy(originalError, {
//     construct(target, args) {
//         const error = new target(...args);
//         return new Proxy(error, {
//             get(obj, prop) {
//                 if (prop === 'stack') {
//                     return obj.stack
//                         .replace(/\/userscript\.html/g, '/muamua/qq.html')
//                         .replace(/\.user\.js/g, '/muamua.qq.js');
//                 } else {
//                     return Reflect.get(obj, prop);
//                 }
//             }
//         });
//     }
// });